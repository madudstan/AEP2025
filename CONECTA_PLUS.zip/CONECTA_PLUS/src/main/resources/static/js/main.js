// URL base da API
const API_BASE_URL = 'http://localhost:8080/api';

// Função para fazer scroll suave
function scrollToSection(sectionId) {
    const element = document.getElementById(sectionId);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
    }
}

// Carregar cursos ao iniciar a página
document.addEventListener('DOMContentLoaded', function() {
    carregarCursos();
    carregarOportunidades();
});

// Função para carregar cursos da API
async function carregarCursos() {
    const cursosList = document.getElementById('cursos-lista');
    
    if (!cursosList) {
        console.log('Elemento cursos-lista não encontrado');
        return;
    }
    
    try {
        console.log('Carregando cursos da API...');
        const response = await fetch(`${API_BASE_URL}/cursos`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const cursos = await response.json();
        console.log('Cursos carregados:', cursos);
        
        cursosList.innerHTML = '';
        
        if (cursos.length === 0) {
            cursosList.innerHTML = '<p style="text-align: center; color: #666; padding: 2rem;">Nenhum curso disponível no momento.</p>';
            return;
        }
        
        cursos.forEach(curso => {
            const levelLabel = {
                'BEGINNER': 'Iniciante',
                'INTERMEDIATE': 'Intermediário',
                'ADVANCED': 'Avançado'
            }[curso.level] || curso.level;
            
            const cursoCard = document.createElement('div');
            cursoCard.className = 'curso-card';
            cursoCard.innerHTML = `
                ${curso.imageUrl ? `<img src="${curso.imageUrl}" alt="${curso.title}" class="curso-image">` : '<div class="curso-image-placeholder">📚</div>'}
                <div class="curso-content">
                    <span class="curso-category">${curso.category}</span>
                    <h3 class="curso-title">${curso.title}</h3>
                    <p class="curso-description">${curso.description}</p>
                    <div class="curso-meta">
                        <span>⏱️ ${curso.duration} horas</span>
                        <span class="curso-level">${levelLabel}</span>
                    </div>
                    <button class="btn btn-primary" onclick="inscreverCurso(${curso.id}, '${curso.title}')">Inscrever-se</button>
                </div>
            `;
            cursosList.appendChild(cursoCard);
        });
    } catch (error) {
        console.error('Erro ao carregar cursos:', error);
        cursosList.innerHTML = `
            <div style="text-align: center; padding: 2rem; color: #dc2626;">
                <p>⚠️ Erro ao carregar cursos. Verifique se o servidor está rodando.</p>
                <button class="btn btn-primary" onclick="carregarCursos()">Tentar Novamente</button>
            </div>
        `;
    }
}

// Função para carregar oportunidades
async function carregarOportunidades() {
    const oportunidadesList = document.getElementById('oportunidades-lista');
    
    if (!oportunidadesList) {
        console.log('Elemento oportunidades-lista não encontrado');
        return;
    }
    
    try {
        // Dados de exemplo (em produção, viria da API)
        const oportunidades = [
            {
                id: 1,
                title: 'Estágio em Desenvolvimento Web',
                type: 'internship',
                company: 'TechStart Solutions',
                location: 'São Paulo, SP',
                deadline: '2025-12-31'
            },
            {
                id: 2,
                title: 'Bolsa de Estudos em Marketing Digital',
                type: 'scholarship',
                company: 'Instituto de Marketing Digital',
                location: 'Online',
                deadline: '2025-11-30'
            },
            {
                id: 3,
                title: 'Hackathon de Inovação Social',
                type: 'event',
                company: 'ONG Inovação para Todos',
                location: 'Rio de Janeiro, RJ',
                deadline: '2025-10-15'
            },
            {
                id: 4,
                title: 'Desenvolvedor Junior - React',
                type: 'job',
                company: 'Digital Innovations',
                location: 'Remoto',
                deadline: '2025-12-01'
            }
        ];
        
        oportunidadesList.innerHTML = '';
        
        oportunidades.forEach(oportunidade => {
            const typeLabel = {
                'internship': 'Estágio',
                'scholarship': 'Bolsa',
                'event': 'Evento',
                'job': 'Emprego'
            }[oportunidade.type];
            
            const oportunidadeCard = document.createElement('div');
            oportunidadeCard.className = 'oportunidade-card';
            oportunidadeCard.innerHTML = `
                <span class="oportunidade-type">${typeLabel}</span>
                <h3 class="oportunidade-title">${oportunidade.title}</h3>
                <p class="oportunidade-company">${oportunidade.company}</p>
                <p class="oportunidade-location">📍 ${oportunidade.location}</p>
                <p class="oportunidade-deadline">⏰ Até ${formatarData(oportunidade.deadline)}</p>
                <button class="btn btn-primary" onclick="candidatarOportunidade(${oportunidade.id}, '${oportunidade.title}')">Candidatar-se</button>
            `;
            oportunidadesList.appendChild(oportunidadeCard);
        });
    } catch (error) {
        console.error('Erro ao carregar oportunidades:', error);
    }
}

// Função para inscrever em curso
function inscreverCurso(cursoId, cursoTitulo) {
    // Verifica se o usuário está logado
    if (confirm(`Deseja se inscrever no curso "${cursoTitulo}"?`)) {
        alert('Funcionalidade de inscrição será implementada em breve!');
        // Aqui você faria uma chamada à API para inscrever o usuário
        // fetch(`${API_BASE_URL}/inscricoes`, { method: 'POST', body: JSON.stringify({ cursoId }) })
    }
}

// Função para candidatar a oportunidade
function candidatarOportunidade(oportunidadeId, oportunidadeTitulo) {
    if (confirm(`Deseja se candidatar à oportunidade "${oportunidadeTitulo}"?`)) {
        alert('Funcionalidade de candidatura será implementada em breve!');
        // Aqui você faria uma chamada à API para registrar a candidatura
    }
}

// Função para formatar data
function formatarData(data) {
    const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
    return new Date(data).toLocaleDateString('pt-BR', options);
}

// Função para buscar cursos por categoria
function buscarPorCategoria(categoria) {
    fetch(`${API_BASE_URL}/cursos/categoria/${categoria}`)
        .then(response => response.json())
        .then(cursos => {
            const cursosList = document.getElementById('cursos-lista');
            cursosList.innerHTML = '';
            
            cursos.forEach(curso => {
                const levelLabel = {
                    'BEGINNER': 'Iniciante',
                    'INTERMEDIATE': 'Intermediário',
                    'ADVANCED': 'Avançado'
                }[curso.level] || curso.level;
                
                const cursoCard = document.createElement('div');
                cursoCard.className = 'curso-card';
                cursoCard.innerHTML = `
                    ${curso.imageUrl ? `<img src="${curso.imageUrl}" alt="${curso.title}" class="curso-image">` : '<div class="curso-image-placeholder">📚</div>'}
                    <div class="curso-content">
                        <span class="curso-category">${curso.category}</span>
                        <h3 class="curso-title">${curso.title}</h3>
                        <p class="curso-description">${curso.description}</p>
                        <div class="curso-meta">
                            <span>⏱️ ${curso.duration} horas</span>
                            <span class="curso-level">${levelLabel}</span>
                        </div>
                        <button class="btn btn-primary" onclick="inscreverCurso(${curso.id}, '${curso.title}')">Inscrever-se</button>
                    </div>
                `;
                cursosList.appendChild(cursoCard);
            });
        })
        .catch(error => {
            console.error('Erro ao buscar cursos:', error);
            alert('Erro ao buscar cursos por categoria');
        });
}
