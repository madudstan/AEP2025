package com.capacitajovem.repository;

import com.capacitajovem.model.Inscricao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface InscricaoRepository extends JpaRepository<Inscricao, Integer> {
    
    List<Inscricao> findByUserId(Integer userId);
    
    List<Inscricao> findByUserIdAndStatus(Integer userId, Inscricao.Status status);
    
    Optional<Inscricao> findByUserIdAndCourseId(Integer userId, Integer courseId);
    
    boolean existsByUserIdAndCourseId(Integer userId, Integer courseId);
    
    long countByUserIdAndStatus(Integer userId, Inscricao.Status status);
}
