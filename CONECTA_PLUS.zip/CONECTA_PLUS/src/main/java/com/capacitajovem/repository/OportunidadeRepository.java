package com.capacitajovem.repository;

import com.capacitajovem.model.Oportunidade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface OportunidadeRepository extends JpaRepository<Oportunidade, Integer> {
    
    List<Oportunidade> findByIsActiveTrue();
    
    List<Oportunidade> findByType(Oportunidade.Tipo type);
    
    List<Oportunidade> findByIsActiveTrueOrderByCreatedAtDesc();
}
