package com.capacitajovem.repository;

import com.capacitajovem.model.Conteudo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConteudoRepository extends JpaRepository<Conteudo, Integer> {
    
    List<Conteudo> findByCourseIdOrderByOrderAsc(Integer courseId);
    
}
