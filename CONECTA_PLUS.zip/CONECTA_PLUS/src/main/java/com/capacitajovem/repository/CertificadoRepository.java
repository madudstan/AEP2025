package com.capacitajovem.repository;

import com.capacitajovem.model.Certificado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CertificadoRepository extends JpaRepository<Certificado, Integer> {
    
    List<Certificado> findByUserId(Integer userId);
    
    Optional<Certificado> findByUserIdAndCourseId(Integer userId, Integer courseId);
    
    Optional<Certificado> findByCertificateCode(String certificateCode);
    
}
