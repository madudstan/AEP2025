package com.capacitajovem.repository;

import com.capacitajovem.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {
    Optional<Usuario> findByOpenId(String openId);
    Optional<Usuario> findByEmail(String email);
}
