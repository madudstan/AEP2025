package com.capacitajovem.service;

import com.capacitajovem.model.Oportunidade;
import com.capacitajovem.repository.OportunidadeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class OportunidadeService {

    @Autowired
    private OportunidadeRepository oportunidadeRepository;

    public List<Oportunidade> listarAtivas() {
        return oportunidadeRepository.findByIsActiveTrueOrderByCreatedAtDesc();
    }

    public List<Oportunidade> listarPorTipo(Oportunidade.Tipo tipo) {
        return oportunidadeRepository.findByType(tipo);
    }

    public Optional<Oportunidade> obterPorId(Integer id) {
        return oportunidadeRepository.findById(id);
    }

    public List<Oportunidade> listarTodas() {
        return oportunidadeRepository.findAll();
    }
}
