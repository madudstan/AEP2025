package com.capacitajovem.service;

import com.capacitajovem.model.Curso;
import com.capacitajovem.repository.CursoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class CursoService {

    @Autowired
    private CursoRepository cursoRepository;

    public List<Curso> listarTodos() {
        return cursoRepository.findAll();
    }

    public List<Curso> listarAtivos() {
        return cursoRepository.findByIsActiveTrue();
    }

    public Optional<Curso> obterPorId(Integer id) {
        return cursoRepository.findById(id);
    }

    public List<Curso> listarPorCategoria(String categoria) {
        return cursoRepository.findByCategory(categoria);
    }

    public Curso criar(Curso curso) {
        return cursoRepository.save(curso);
    }

    public Curso atualizar(Integer id, Curso cursoAtualizado) {
        Optional<Curso> cursoExistente = cursoRepository.findById(id);
        if (cursoExistente.isPresent()) {
            Curso curso = cursoExistente.get();
            curso.setTitle(cursoAtualizado.getTitle());
            curso.setDescription(cursoAtualizado.getDescription());
            curso.setCategory(cursoAtualizado.getCategory());
            curso.setDuration(cursoAtualizado.getDuration());
            curso.setLevel(cursoAtualizado.getLevel());
            curso.setImageUrl(cursoAtualizado.getImageUrl());
            return cursoRepository.save(curso);
        }
        return null;
    }

    public void deletar(Integer id) {
        cursoRepository.deleteById(id);
    }

}
