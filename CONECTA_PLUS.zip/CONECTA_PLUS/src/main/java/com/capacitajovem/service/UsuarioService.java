package com.capacitajovem.service;

import com.capacitajovem.model.Usuario;
import com.capacitajovem.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    public Usuario cadastrarUsuario(String nome, String email, String senha) {
        Optional<Usuario> usuarioExistente = usuarioRepository.findByEmail(email);
        if (usuarioExistente.isPresent()) {
            throw new RuntimeException("Email já cadastrado no sistema");
        }

        // Cria um novo usuário
        Usuario novoUsuario = new Usuario();
        novoUsuario.setOpenId(gerarOpenId()); // Gera um ID único
        novoUsuario.setName(nome);
        novoUsuario.setEmail(email);
        novoUsuario.setPassword(senha);
        novoUsuario.setLoginMethod("local");
        novoUsuario.setRole(Usuario.Papel.STUDENT);
        novoUsuario.setPoints(0);
        novoUsuario.setCreatedAt(LocalDateTime.now());
        novoUsuario.setUpdatedAt(LocalDateTime.now());
        novoUsuario.setLastSignedIn(LocalDateTime.now());

        // Salva no banco de dados
        return usuarioRepository.save(novoUsuario);
    }

    public Optional<Usuario> login(String email, String senha) {
        Optional<Usuario> usuario = usuarioRepository.findByEmail(email);
        
        if (usuario.isPresent() && usuario.get().getPassword().equals(senha)) {
            // Atualiza o último login
            Usuario user = usuario.get();
            user.setLastSignedIn(LocalDateTime.now());
            usuarioRepository.save(user);
            return Optional.of(user);
        }
        
        return Optional.empty();
    }

    private String gerarOpenId() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 32);
    }

    public Optional<Usuario> buscarPorEmail(String email) {
        return usuarioRepository.findByEmail(email);
    }
}
