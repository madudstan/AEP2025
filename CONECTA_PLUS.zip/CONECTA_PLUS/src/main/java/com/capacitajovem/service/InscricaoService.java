package com.capacitajovem.service;

import com.capacitajovem.model.Inscricao;
import com.capacitajovem.repository.InscricaoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class InscricaoService {

    @Autowired
    private InscricaoRepository inscricaoRepository;

    // Inscrever usuário em um curso
    public Inscricao inscrever(Integer userId, Integer courseId) {
        // Verifica se já está inscrito
        if (inscricaoRepository.existsByUserIdAndCourseId(userId, courseId)) {
            throw new RuntimeException("Você já está inscrito neste curso!");
        }

        Inscricao inscricao = new Inscricao();
        inscricao.setUserId(userId);
        inscricao.setCourseId(courseId);
        inscricao.setStatus(Inscricao.Status.active);
        inscricao.setProgress(0);
        inscricao.setEnrolledAt(LocalDateTime.now());

        return inscricaoRepository.save(inscricao);
    }

    // Listar cursos do usuário
    public List<Inscricao> listarCursosDoUsuario(Integer userId) {
        return inscricaoRepository.findByUserId(userId);
    }

    // Listar cursos ativos do usuário
    public List<Inscricao> listarCursosAtivos(Integer userId) {
        return inscricaoRepository.findByUserIdAndStatus(userId, Inscricao.Status.active);
    }

    // Atualizar progresso
    public Inscricao atualizarProgresso(Integer userId, Integer courseId, Integer progresso) {
        Optional<Inscricao> inscricaoOpt = inscricaoRepository.findByUserIdAndCourseId(userId, courseId);
        
        if (inscricaoOpt.isEmpty()) {
            throw new RuntimeException("Inscrição não encontrada");
        }

        Inscricao inscricao = inscricaoOpt.get();
        inscricao.setProgress(progresso);

        // Se completou 100%, marca como concluído
        if (progresso >= 100) {
            inscricao.setStatus(Inscricao.Status.completed);
            inscricao.setCompletedAt(LocalDateTime.now());
        }

        return inscricaoRepository.save(inscricao);
    }

    // Contar cursos concluídos
    public long contarCursosConcluidos(Integer userId) {
        return inscricaoRepository.countByUserIdAndStatus(userId, Inscricao.Status.completed);
    }

    // Verificar se está inscrito
    public boolean estaInscrito(Integer userId, Integer courseId) {
        return inscricaoRepository.existsByUserIdAndCourseId(userId, courseId);
    }
}
