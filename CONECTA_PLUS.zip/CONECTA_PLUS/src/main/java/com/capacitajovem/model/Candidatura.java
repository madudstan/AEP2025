package com.capacitajovem.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "applications")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Candidatura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "userId", nullable = false)
    private Integer userId;

    @Column(name = "opportunityId", nullable = false)
    private Integer opportunityId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private StatusCandidatura status = StatusCandidatura.pending;

    @Column(name = "coverLetter", columnDefinition = "TEXT")
    private String coverLetter;

    @Column(name = "appliedAt", nullable = false, updatable = false)
    private LocalDateTime appliedAt = LocalDateTime.now();

    @Column(name = "updatedAt", nullable = false)
    private LocalDateTime updatedAt = LocalDateTime.now();

    public enum StatusCandidatura {
        pending, accepted, rejected
    }

}
