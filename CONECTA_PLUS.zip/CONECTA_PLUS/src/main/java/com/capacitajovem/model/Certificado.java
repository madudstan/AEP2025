package com.capacitajovem.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "certificates")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Certificado {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "userId", nullable = false)
    private Integer userId;

    @Column(name = "courseId", nullable = false)
    private Integer courseId;

    @Column(name = "certificateCode", nullable = false, unique = true, length = 100)
    private String certificateCode;

    @Column(name = "issuedAt", nullable = false, updatable = false)
    private LocalDateTime issuedAt = LocalDateTime.now();

    @Column(name = "certificateUrl", columnDefinition = "TEXT")
    private String certificateUrl;

}
