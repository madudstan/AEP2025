package com.capacitajovem.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "progress")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Progresso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "userId", nullable = false)
    private Integer userId;

    @Column(name = "contentId", nullable = false)
    private Integer contentId;

    @Column(name = "completed", nullable = false)
    private Boolean completed = false;

    @Column(name = "score")
    private Integer score;

    @Column(name = "completedAt")
    private LocalDateTime completedAt;

    @Column(name = "createdAt", nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

}
