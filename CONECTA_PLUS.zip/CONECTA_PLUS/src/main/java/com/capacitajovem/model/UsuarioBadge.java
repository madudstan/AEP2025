package com.capacitajovem.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "userBadges")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsuarioBadge {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "userId", nullable = false)
    private Integer userId;

    @Column(name = "badgeId", nullable = false)
    private Integer badgeId;

    @Column(name = "earnedAt", nullable = false, updatable = false)
    private LocalDateTime earnedAt = LocalDateTime.now();

}
