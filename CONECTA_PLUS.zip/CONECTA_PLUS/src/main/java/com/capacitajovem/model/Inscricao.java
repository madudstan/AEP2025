package com.capacitajovem.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "enrollments")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Inscricao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "userId", nullable = false)
    private Integer userId;

    @Column(name = "courseId", nullable = false)
    private Integer courseId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private Status status = Status.active;

    @Column(name = "progress", nullable = false)
    private Integer progress = 0;

    @Column(name = "enrolledAt", nullable = false)
    private LocalDateTime enrolledAt = LocalDateTime.now();

    @Column(name = "completedAt")
    private LocalDateTime completedAt;

    // Relacionamentos
    @ManyToOne
    @JoinColumn(name = "userId", insertable = false, updatable = false)
    private Usuario usuario;

    @ManyToOne
    @JoinColumn(name = "courseId", insertable = false, updatable = false)
    private Curso curso;

    public enum Status {
        active, completed, dropped
    }
}
