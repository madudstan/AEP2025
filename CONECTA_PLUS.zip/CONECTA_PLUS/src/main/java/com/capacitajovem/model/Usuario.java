package com.capacitajovem.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "openId", nullable = false, unique = true, length = 64)
    private String openId;

    @Column(name = "password")
    private String password;

    @Column(name = "name", columnDefinition = "TEXT")
    private String name;

    @Column(name = "email", length = 320)
    private String email;

    @Column(name = "loginMethod", length = 64)
    private String loginMethod;

    @Enumerated(EnumType.STRING)
    @Column(name = "role", nullable = false)
    private Papel role = Papel.STUDENT;

    @Column(name = "bio", columnDefinition = "TEXT")
    private String bio;

    @Column(name = "phone", length = 20)
    private String phone;

    @Column(name = "points", nullable = false)
    private Integer points = 0;

    @Column(name = "createdAt", nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updatedAt", nullable = false)
    private LocalDateTime updatedAt = LocalDateTime.now();

    @Column(name = "lastSignedIn", nullable = false)
    private LocalDateTime lastSignedIn = LocalDateTime.now();

    public enum Papel {
        USER, ADMIN, STUDENT, MENTOR, COMPANY
    }

}
