package com.capacitajovem.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "contents")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Conteudo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "courseId", nullable = false)
    private Integer courseId;

    @Column(name = "title", nullable = false, length = 255)
    private String title;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(name = "contentType", nullable = false)
    private TipoConteudo contentType;

    @Column(name = "contentUrl", columnDefinition = "TEXT")
    private String contentUrl;

    @Column(name = "contentText", columnDefinition = "TEXT")
    private String contentText;

    @Column(name = "`order`", nullable = false)
    private Integer order;

    @Column(name = "duration")
    private Integer duration;

    @Column(name = "createdAt", nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public enum TipoConteudo {
        video, text, quiz, document
    }

}
