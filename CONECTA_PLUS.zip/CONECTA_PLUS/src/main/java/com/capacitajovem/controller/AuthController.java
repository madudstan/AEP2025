package com.capacitajovem.controller;

import com.capacitajovem.model.Usuario;
import com.capacitajovem.service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
public class AuthController {

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    @GetMapping("/cadastro")
    public String showCadastroPage() {
        return "cadastro";
    }

    @PostMapping("/login-simulado")
    public String loginSimulado(@RequestParam String email, 
                                @RequestParam String senha,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {
        try {
            Optional<Usuario> usuario = usuarioService.login(email, senha);
            
            if (usuario.isPresent()) {
                session.setAttribute("usuarioLogado", usuario.get());
                session.setAttribute("usuarioId", usuario.get().getId());
                session.setAttribute("usuarioNome", usuario.get().getName());
                session.setAttribute("usuarioEmail", usuario.get().getEmail());

                return "redirect:/dashboard";
            } else {
                redirectAttributes.addFlashAttribute("erro", "Email ou senha incorretos");
                return "redirect:/login";
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erro", "Erro ao realizar login: " + e.getMessage());
            return "redirect:/login";
        }
    }

    @PostMapping("/cadastro-simulado")
    public String cadastroSimulado(@RequestParam String nome, 
                                   @RequestParam String email, 
                                   @RequestParam String senha,
                                   RedirectAttributes redirectAttributes) {
        try {
            if (nome == null || nome.trim().isEmpty()) {
                redirectAttributes.addFlashAttribute("erro", "Nome é obrigatório");
                return "redirect:/cadastro";
            }
            
            if (email == null || email.trim().isEmpty()) {
                redirectAttributes.addFlashAttribute("erro", "Email é obrigatório");
                return "redirect:/cadastro";
            }
            
            if (senha == null || senha.trim().isEmpty() || senha.length() < 6) {
                redirectAttributes.addFlashAttribute("erro", "Senha deve ter no mínimo 6 caracteres");
                return "redirect:/cadastro";
            }

            Usuario novoUsuario = usuarioService.cadastrarUsuario(nome, email, senha);

            redirectAttributes.addFlashAttribute("mensagemSucesso", 
                "Cadastro realizado com sucesso! Faça login para acessar a plataforma.");
            return "redirect:/login";
            
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
            return "redirect:/cadastro";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erro", "Erro ao realizar cadastro. Tente novamente.");
            e.printStackTrace();
            return "redirect:/cadastro";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session, RedirectAttributes redirectAttributes) {
        session.invalidate();
        redirectAttributes.addFlashAttribute("mensagemSucesso", "Você saiu do sistema com sucesso!");
        return "redirect:/login";
    }
}
