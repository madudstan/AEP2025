package com.capacitajovem.controller;

import com.capacitajovem.model.Curso;
import com.capacitajovem.service.CursoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/cursos")
@CrossOrigin(origins = "*")
public class CursoController {

    @Autowired
    private CursoService cursoService;

    @GetMapping
    public ResponseEntity<List<Curso>> listarTodos() {
        return ResponseEntity.ok(cursoService.listarAtivos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Curso> obterPorId(@PathVariable Integer id) {
        Optional<Curso> curso = cursoService.obterPorId(id);
        return curso.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/categoria/{categoria}")
    public ResponseEntity<List<Curso>> listarPorCategoria(@PathVariable String categoria) {
        return ResponseEntity.ok(cursoService.listarPorCategoria(categoria));
    }

    @PostMapping
    public ResponseEntity<Curso> criar(@RequestBody Curso curso) {
        return ResponseEntity.ok(cursoService.criar(curso));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Curso> atualizar(@PathVariable Integer id, @RequestBody Curso curso) {
        Curso cursoAtualizado = cursoService.atualizar(id, curso);
        if (cursoAtualizado != null) {
            return ResponseEntity.ok(cursoAtualizado);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Integer id) {
        cursoService.deletar(id);
        return ResponseEntity.noContent().build();
    }

}
