package com.capacitajovem.controller;

import com.capacitajovem.model.Curso;
import com.capacitajovem.model.Inscricao;
import com.capacitajovem.model.Oportunidade;
import com.capacitajovem.model.Usuario;
import com.capacitajovem.service.CursoService;
import com.capacitajovem.service.InscricaoService;
import com.capacitajovem.service.OportunidadeService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.stream.Collectors;

@Controller
public class DashboardController {

    @Autowired
    private CursoService cursoService;

    @Autowired
    private InscricaoService inscricaoService;

    @Autowired
    private OportunidadeService oportunidadeService;

    // Dashboard
    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
        
        if (usuarioLogado == null) {
            return "redirect:/login";
        }

        long cursosInscritos = inscricaoService.listarCursosAtivos(usuarioLogado.getId()).size();
        long cursosConcluidos = inscricaoService.contarCursosConcluidos(usuarioLogado.getId());
        
        model.addAttribute("usuario", usuarioLogado);
        model.addAttribute("nomeUsuario", usuarioLogado.getName());
        model.addAttribute("emailUsuario", usuarioLogado.getEmail());
        model.addAttribute("pontosUsuario", usuarioLogado.getPoints());
        model.addAttribute("cursosInscritos", cursosInscritos);
        model.addAttribute("cursosConcluidos", cursosConcluidos);
        
        return "dashboard";
    }
    
    // Página de Meus Cursos
    @GetMapping("/meus-cursos")
    public String meusCursos(HttpSession session, Model model) {
        Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
        
        if (usuarioLogado == null) {
            return "redirect:/login";
        }
        
        List<Inscricao> inscricoes = inscricaoService.listarCursosDoUsuario(usuarioLogado.getId());
        
        model.addAttribute("usuario", usuarioLogado);
        model.addAttribute("inscricoes", inscricoes);
        
        return "meus-cursos";
    }
    
    // Página de Progresso
    @GetMapping("/meu-progresso")
    public String meuProgresso(HttpSession session, Model model) {
        Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
        
        if (usuarioLogado == null) {
            return "redirect:/login";
        }
        
        List<Inscricao> inscricoes = inscricaoService.listarCursosAtivos(usuarioLogado.getId());
        
        model.addAttribute("usuario", usuarioLogado);
        model.addAttribute("inscricoes", inscricoes);
        
        return "meu-progresso";
    }
    
    // Página de Oportunidades
    @GetMapping("/oportunidades")
    public String oportunidades(HttpSession session, Model model) {
        Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
        
        if (usuarioLogado == null) {
            return "redirect:/login";
        }
        
        List<Oportunidade> oportunidades = oportunidadeService.listarAtivas();
        
        model.addAttribute("usuario", usuarioLogado);
        model.addAttribute("oportunidades", oportunidades);
        
        return "oportunidades";
    }
    
    // Página de Certificados
    @GetMapping("/certificados")
    public String certificados(HttpSession session, Model model) {
        Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
        
        if (usuarioLogado == null) {
            return "redirect:/login";
        }
        
        List<Inscricao> cursosConcluidos = inscricaoService.listarCursosDoUsuario(usuarioLogado.getId())
            .stream()
            .filter(i -> i.getStatus() == Inscricao.Status.completed)
            .collect(Collectors.toList());
        
        model.addAttribute("usuario", usuarioLogado);
        model.addAttribute("cursosConcluidos", cursosConcluidos);
        
        return "certificados";
    }
    
    // Página de Explorar Cursos
    @GetMapping("/explorar-cursos")
    public String explorarCursos(HttpSession session, Model model) {
        Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
        
        if (usuarioLogado == null) {
            return "redirect:/login";
        }
        
        List<Curso> cursos = cursoService.listarAtivos();
        
        model.addAttribute("usuario", usuarioLogado);
        model.addAttribute("cursos", cursos);
        
        return "explorar-cursos";
    }
    
    // Inscrever em curso
    @PostMapping("/inscrever/{cursoId}")
    public String inscrever(@PathVariable Integer cursoId, 
                           HttpSession session, 
                           RedirectAttributes redirectAttributes) {
        Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
        
        if (usuarioLogado == null) {
            return "redirect:/login";
        }
        
        try {
            inscricaoService.inscrever(usuarioLogado.getId(), cursoId);
            redirectAttributes.addFlashAttribute("mensagemSucesso", "Inscrição realizada com sucesso!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
        }
        
        return "redirect:/meus-cursos";
    }
    
    // Perfil do Usuário
    @GetMapping("/perfil")
    public String perfil(HttpSession session, Model model) {
        Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
        
        if (usuarioLogado == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("usuario", usuarioLogado);
        
        return "perfil";
    }
}
